RELATIONSKOMPASSEN – INSTALLATION PÅ IPHONE

1. Skapa ett gratis konto på https://github.com (om du inte redan har ett).
2. Skapa ett nytt PUBLIC repository, t.ex. "relationskompassen".
3. Ladda upp ALLA filer i den här mappen (index.html, app.js, sw.js, manifest.webmanifest och tre PNG-ikoner) till repositoryts rot. Ladda inte upp ZIP-filen som enda fil.
4. Gå till Settings > Pages. Under Build and deployment: välj Deploy from a branch, branch main, folder /(root). Klicka Save.
5. Vänta tills GitHub visar din publicerade URL, normalt https://DITT-ANVANDARNAMN.github.io/relationskompassen/ . Använd adressen som GitHub visar.
6. Öppna URL:en i Safari på iPhone. Tryck Dela > Lägg till på hemskärmen > Lägg till.
7. Starta Relationskompassen från hemskärmen. Välj startdatum i Inställningar.

OBS: Repositoryt är offentligt, men dina personliga anteckningar och skattningar lagras ENBART i webbläsaren på din enhet och ska aldrig läggas in i GitHub. Exportera en säkerhetskopia från appens Inställningar ibland. Om du tar bort webbplatsdata eller appen kan lokala data försvinna.

Om knappar inte fungerar: kontrollera att du öppnar https-adressen i Safari och inte index.html från Filer.
